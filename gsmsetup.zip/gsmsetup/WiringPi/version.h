#define VERSION "2.70"
#define VERSION_MAJOR 2
#define VERSION_MINOR 70
