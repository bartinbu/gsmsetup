#!/bin/bash
sudo systemctl mask serial-getty@ttyAMA0.service
sudo gpio mode 1 out
sudo gpio mode 6 out
sudo gpio write 6 1
sudo gpio write 1 1
sudo gpio write 6 0
sleep 3
sudo gpio write 6 1
sleep 3
sudo pppd file /etc/ppp/options-mobile connect "/usr/sbin/chat -v -t80 -f /etc/ppp/chatscripts/mobile-modem.chat" debug
echo "Service Running"
while true; do
    sleep 300
    # Run ifconfig command and search for ppp0 interface
    ifconfig | grep -q "ppp0"
    
    # Check the exit status to determine if ppp0 was found
    if [ $? -eq 0 ]; then
        echo "ppp0 interface exists."
    else
        echo "ppp0 interface does not exist."
        systemctl reboot gsm
    fi
done