#include <iostream>
#include <wiringPi.h>
#include <unistd.h>

using namespace std;

int main()
{
wiringPiSetup();
pinMode(1,OUTPUT);
pinMode(6,OUTPUT);
digitalWrite(6,1);
cout<<"Turning on Power Switch"<<endl;
digitalWrite(1,1);
digitalWrite(6,0);
cout<<"Power Successfuly Turned On"<<endl;
cout<<"Starting GSM Module"<<endl;
usleep(2000*1000);
digitalWrite(6,1);
cout<<"GSM Successfully Booted"<<endl;
}
