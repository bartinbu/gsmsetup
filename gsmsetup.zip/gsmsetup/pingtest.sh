#!/bin/bash
ping www.google.com -I ppp0 -c 5
