# GND Teknik Raspberry Pi 3 GSM Shield Kullanımı
Bu proje GND Teknik Raspberry Pi 3 GSM Shield için gerekli kurum aşamalarını içerir. 

http://www.gndteknik.com/gndkits/rgs-01-raspberry-pi-gsm-shield 

Kurulumdan önce gerekli olanlar
* Raspbian'ın son güncel sürümünü içeren SD Kart
* Internet bağlantısı (Sadece ilk kurulum için)
* [GND Teknik Raspberry Pi 3 GSM Shield]

Dikkat! Bu Shield Raspberry Pi 3'ün Bluetooth portlarını kullanıyor. Bu kurulumu gerçekleştireceğinizde Raspberry Pi 3'ün Bluetooth özelliği devre dışı kalacaktır.

Kurulum için herhangi bir dizine bu repositoryi kopyalayın
```sh
git clone https://raziel@git.raziel.io/raziel/gndteknik-raspberry-gsm.git gsm-tools
cd gsm-tools
```
Daha sonra install.sh dosyasına +x modu ekleyin
```sh
chmod +x install.sh
```
sudo haklarıyla install.sh dosyasını çalıştırın.
```sh
sudo ./install.sh
```

Kurulum tamamlandıkan sonra bluetooth servislerini devre dışı bırakmak için aşağıda ki komutu çalıştırın.
```sh
systemctl mask serial-getty@ttyAMA0.service
```

GSM Shield'i devreye almak için gsm-tools dizininde gsm-bootup.sh dosyasını çalıştırın
```sh
./gsm-bootup.sh
```
GSM devreye girdiğinde GPRS bağlantısını sağlamak için aşağıda ki komutu çalıştırın.
```sh
sudo pon internet
```

GSM bağlantısını kontrol etmek için pingtest.sh scriptini çalıştırabilirsiniz.
```sh
./pingtest.sh
``` 

GPRS bağlantısını kesmek için aşağıdaki komutu çalıştırın.
```sh
sudo poff
```









[GND Teknik Raspberry Pi 3 GSM Shield]: http://www.gndteknik.com/gndkits/rgs-01-raspberry-pi-gsm-shield