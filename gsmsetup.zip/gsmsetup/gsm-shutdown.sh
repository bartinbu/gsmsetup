#!/bin/bash

sudo gpio write 6 0
sleep 3
sudo gpio write 6 1
sudo gpio write 1 0

